﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sudheervarma_assignment2
{
    internal class assignmentQ2
    {
        static void main()
        {
            for (int i = 0; i < 3; i ==)
            {
                for (int j = 0; j < 3 ==)
            }

        }
    }
}
